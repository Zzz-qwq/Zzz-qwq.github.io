"""Run: python -m unittest -v test_todo_v2.py (no GUI/API needed)."""
import json
import tempfile
import unittest
from pathlib import Path
from todo_v2_core import (load_tasks_safely, save_tasks_atomically,
                          archive_completed_task, parse_extraction_result,
                          build_extraction_user_prompt, equivalent_title)

CASE_TEXT = ("@赵子奕（无）负责：今天之内需要将成绩报表发给浙理工。课堂成绩的话，都是讲师打分+课堂出勤（有记录表）。"
             "结业考试学校负责，我们提供考勤和作业评分。这个需要你今天制作一下。此任务为最高优先级。@黎想协助。\n"
             "合同目前是资料整理的二期回款8400未收回，还需要和浙理工那边对齐一下资料的整理，@赵子奕（无）@黎想搭档一下，"
             "老师的意思是尽量对后续的课程开个会，资料也在会上对齐，建议@张果参会。\n"
             "课程实施合同还未签，推进签署以及回款，三门理论课已经实施完了，实践课和实验课还缺学时。")


class CoreTests(unittest.TestCase):
    def test_case001_confirmed_and_pending(self):
        response = {
            "confirmed_tasks": [
                {"text": "制作并发送浙理工成绩报表", "role": "主责", "priority": "高", "due": "2026-10-13",
                 "deadline_raw": "今天之内", "evidence": "今天之内需要将成绩报表发给浙理工"},
                {"text": "与黎想协作对齐浙理工资料", "role": "共同", "priority": "", "due": "",
                 "evidence": "还需要和浙理工那边对齐一下资料的整理"},
            ],
            "needs_confirmation": [
                {"text": "确认课程会议的召集人", "evidence": "尽量对后续的课程开个会"},
                {"text": "确认资料整理二期回款跟进人", "evidence": "二期回款8400未收回"},
                {"text": "确认实施合同签署及回款负责人", "evidence": "课程实施合同还未签，推进签署以及回款"},
            ],
        }
        result = parse_extraction_result(json.dumps(response, ensure_ascii=False), CASE_TEXT, "")
        self.assertEqual(len(result["confirmed_tasks"]), 2)
        self.assertEqual(len(result["needs_confirmation"]), 3)
        self.assertEqual(result["confirmed_tasks"][0]["due"], "")  # '今天' without source date
        self.assertEqual(result["confirmed_tasks"][0]["priority"], "高")

    def test_case002_assistant_role(self):
        ai_response = {"confirmed_tasks": [{"text": "协助赵子奕完成浙理工报表", "role": "协助",
                        "evidence": "@黎想协助"}], "needs_confirmation": []}
        out = parse_extraction_result(ai_response, CASE_TEXT)
        self.assertEqual(out["confirmed_tasks"][0]["role"], "协助")

    def test_fake_evidence_moves_to_pending(self):
        out = parse_extraction_result({"confirmed_tasks": [{"text": "帮老板买咖啡", "role": "主责",
                                        "evidence": "老板让我买咖啡"}], "needs_confirmation": []}, CASE_TEXT)
        self.assertEqual(len(out["confirmed_tasks"]), 0)
        self.assertEqual(len(out["needs_confirmation"]), 1)

    def test_exact_duplicates_removed_but_different_contracts_preserved(self):
        obj = {"confirmed_tasks": [], "needs_confirmation": [
            {"text": "跟进合同A", "evidence": "合同"},
            {"text": "跟进合同A", "evidence": "合同"},
            {"text": "跟进合同B", "evidence": "合同"}]}
        out = parse_extraction_result(obj, "合同 A B")
        self.assertEqual(len(out["needs_confirmation"]), 2)
        self.assertFalse(equivalent_title("跟进合同A", "跟进合同B"))

    def test_name_and_message_date_validity(self):
        with self.assertRaises(ValueError):
            build_extraction_user_prompt("", "abc")
        with self.assertRaises(ValueError):
            build_extraction_user_prompt("赵子奕", "abc", "2026-20-88")
        self.assertIn("2026-10-13", build_extraction_user_prompt("赵子奕", "abc", "2026-10-13"))

    def test_atomic_save_preserves_previous_version(self):
        with tempfile.TemporaryDirectory() as folder:
            p = str(Path(folder) / "tasks.json")
            save_tasks_atomically(p, [{"id": 1, "text": "第一次"}])
            save_tasks_atomically(p, [{"id": 1, "text": "第二次"}])
            self.assertEqual(load_tasks_safely(p)[0]["text"], "第二次")
            self.assertEqual(load_tasks_safely(p + ".bak")[0]["text"], "第一次")
            with open(p, "w", encoding="utf-8") as f:
                f.write("{{invalid")
            with self.assertRaises(RuntimeError):
                load_tasks_safely(p)
            with self.assertRaises(RuntimeError):
                save_tasks_atomically(p, [])
            self.assertEqual(Path(p).read_text(encoding="utf-8"), "{{invalid")

    def test_archive_once_only(self):
        with tempfile.TemporaryDirectory() as folder:
            archive_path = str(Path(folder) / "归档.md")
            task = {"id": 1, "text": "提交成绩报表", "done": False,
                    "priority": "高", "start": "", "due": ""}
            self.assertTrue(archive_completed_task(archive_path, task))
            self.assertFalse(archive_completed_task(archive_path, task))
            self.assertEqual(Path(archive_path).read_text(encoding="utf-8").count("提交成绩报表"), 1)
            self.assertTrue(task.get("archived_at"))


if __name__ == "__main__":
    unittest.main()
