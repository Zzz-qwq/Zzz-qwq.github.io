"""Safely update the existing public desktop-todo todo_desktop.py in place.

Put this file, todo_v2_core.py and todo_v2_review.py next to your ORIGINAL
`todo_desktop.py` and run `python upgrade_todo_v2.py`.
This utility never downloads or uploads any data.
"""
import ast
import datetime as dt
import os
from pathlib import Path
import shutil
import sys
import tempfile

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "todo_desktop.py"
MARK = "# TODO_V2_PATCHED_2026_10"


def replace_span(s, start, end, new, label):
    a, b = s.find(start), s.find(end)
    if a < 0 or b <= a:
        raise RuntimeError(f"源码布局不符合公开版本：{label}。没有修改任何文件，请不要强行覆盖。")
    if s.find(start, a + 1) >= 0:
        raise RuntimeError(f"发现重复定义：{label}。已取消升级。")
    return s[:a] + new.rstrip() + "\n" + s[b:]


def patch(src):
    if MARK in src:
        raise RuntimeError("这个 todo_desktop.py 已安装 v2，请勿重复运行升级。")
    if "class AiDialog(tk.Toplevel):" not in src or "ARCHIVE_FILE" not in src:
        raise RuntimeError("没有找到对应版本的 Todo 主程序，已停止升级。")
    imports = (
        'from datetime import datetime, date, timedelta\n'
        'from tkinter import messagebox\n'
        'from todo_v2_core import (load_tasks_safely, save_tasks_atomically,\n'
        '    archive_completed_task, ensure_archive_file,\n'
        '    EXTRACT_SYSTEM_PROMPT, build_extraction_user_prompt, parse_extraction_result)\n'
        'from todo_v2_review import CandidateReviewDialog\n'
        + MARK + '\n'
    )
    line = 'from datetime import datetime, date, timedelta\n'
    if src.count(line) != 1:
        raise RuntimeError("未找到唯一的 datetime 导入语句。")
    s = src.replace(line, imports)

    s = replace_span(s, '    def load_tasks(self):\n', '    def add_task(self):\n', '''    def load_tasks(self):
        return load_tasks_safely(DATA_FILE)

    def save_tasks(self):
        save_tasks_atomically(DATA_FILE, self.tasks)

''', '加载/保存任务')

    s = replace_span(s, '    def toggle_done(self, task_id):\n', '    def toggle_expand(self, task_id):\n', '''    def toggle_done(self, task_id):
        for task in self.tasks:
            if task["id"] != task_id:
                continue
            if task.get("done"):
                task["done"] = False
            else:
                try:
                    archive_completed_task(ARCHIVE_FILE, task)
                except OSError as exc:
                    messagebox.showerror("归档失败", "任务未标记完成，归档写入失败：" + str(exc), parent=self.root)
                    return
                task["done"] = True
            try:
                self.save_tasks()
            except Exception as exc:
                messagebox.showerror("保存失败", str(exc), parent=self.root)
                return
            self.render()
            break

    def archive_task(self, task):
        """保留旧方法名，供已有脚本调用；实际写入由安全归档函数处理。"""
        return archive_completed_task(ARCHIVE_FILE, task)

''', '完成/归档逻辑')

    s = replace_span(s, '    def open_archive(self):\n', '    def change_priority(self, task_id, value):\n', '''    def open_archive(self):
        try:
            ensure_archive_file(ARCHIVE_FILE)
            if os.name == "nt":
                os.startfile(ARCHIVE_FILE)
            elif os.sys.platform == "darwin":
                subprocess.Popen(["open", ARCHIVE_FILE])
            else:
                subprocess.Popen(["xdg-open", ARCHIVE_FILE])
        except OSError as exc:
            messagebox.showerror("无法打开归档", str(exc), parent=self.root)

''', '归档入口')

    # Require explicit identity, don't silently treat “我” as an ungrounded person.
    old = 'self.owner_var = tk.StringVar(value="我")'
    if s.count(old) != 1:
        raise RuntimeError("找不到唯一的任务归属人输入框。")
    s = s.replace(old, 'self.owner_var = tk.StringVar(value="")')

    pos = '        self.owner_entry.pack(side="left", padx=(6, 0))\n'
    if s.count(pos) != 1:
        raise RuntimeError("找不到插入消息日期的合适位置。")
    s = s.replace(pos, pos + '''        date_row = tk.Frame(self, bg=BG2)
        date_row.pack(fill="x", padx=12, pady=(0, 5))
        tk.Label(date_row, text="原消息日期（可选）", bg=BG2, fg=FG,
                 font=app.font_small).pack(side="left")
        self.message_date_var = tk.StringVar(value="")
        tk.Entry(date_row, textvariable=self.message_date_var, bg=BG3, fg=FG,
                 insertbackground=FG, relief="flat", width=14).pack(side="left", padx=6)
        tk.Label(date_row, text="YYYY-MM-DD；不填则不换算相对时间",
                 bg=BG2, fg=FG_MUTED, font=app.font_small).pack(side="left")
''')
    s = replace_span(s, '        self.opt_mode = tk.StringVar(value="both")\n', '        self.box.bind("<Control-Return>", lambda e: self.run_ai())\n', '''        opt = tk.Frame(self, bg=BG2)
        opt.pack(fill="x", padx=12, pady=(0, 4))
        tk.Label(opt, text="v2：仅提取新任务，先人工确认；旧任务优先级不自动修改",
                 bg=BG2, fg=FG_MUTED, font=app.font_small).pack(side="left")
''', 'AI 模式')

    s = replace_span(s, '    def run_ai(self):\n', '    def _fail(self, err):\n', '''    def run_ai(self):
        raw = self.box.get("1.0", "end-1c").strip()
        owner = self.owner_var.get().strip()
        msg_date = self.message_date_var.get().strip()
        if not raw:
            self.status.config(text="请先粘贴原始信息", fg=RED)
            return
        try:
            prompt = build_extraction_user_prompt(owner, raw, msg_date)
        except ValueError as exc:
            self.status.config(text=str(exc), fg=RED)
            return
        using_ai = bool(read_api_key())
        self.btn_go.config(state="disabled")
        self.status.config(text="AI 识别中…" if using_ai else "离线拆分中…", fg=FG_MUTED)
        threading.Thread(target=self._work, args=(raw, prompt, msg_date, using_ai), daemon=True).start()

    def _work(self, raw, prompt, msg_date, using_ai):
        try:
            if using_ai:
                reply = call_deepseek(prompt)
                candidates = parse_extraction_result(reply, raw, msg_date)
            else:
                # Rule-based offline fallback cannot infer owner; do not pretend that it can.
                items = local_organize(raw)
                candidates = {"confirmed_tasks": [], "needs_confirmation": []}
                for item in items:
                    candidates["needs_confirmation"].append({
                        "text": item.get("text", ""), "priority": item.get("priority", "中"),
                        "due": "", "deadline_raw": "", "evidence": item.get("text", ""),
                        "note": "", "reason": "离线规则仅能拆分文本，无法确定负责人和日期"})
            self.after(0, lambda: self._show_review(candidates, using_ai))
        except Exception as exc:
            error = str(exc)
            self.after(0, lambda: self._fail(error))

    def _show_review(self, candidates, using_ai):
        self.btn_go.config(state="normal")
        n = len(candidates["confirmed_tasks"]) + len(candidates["needs_confirmation"])
        self.status.config(text=f"识别到 {n} 项候选；审核后才会加入待办", fg=GREEN)
        CandidateReviewDialog(self.app, candidates, "ai" if using_ai else "local", self.owner_var.get().strip())

''', 'AI 识别、预览、确认流程')

    s = replace_span(s, 'def call_deepseek(prompt):\n', 'def parse_tasks_json(text):\n', '''def call_deepseek(prompt):
    key = read_api_key()
    if not key:
        raise RuntimeError("未找到 DeepSeek API Key")
    payload = {
        "model": DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": EXTRACT_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
        "max_tokens": 4000,
    }
    req = urllib.request.Request(
        DEEPSEEK_API_URL,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return body["choices"][0]["message"]["content"]

''', 'DeepSeek 提取规则')

    s = replace_span(s, 'def main():\n', 'if __name__ == "__main__":\n', '''def main():
    root = tk.Tk()
    try:
        app = TodoApp(root)
    except Exception as exc:
        messagebox.showerror("Todo 启动失败（任务数据未被覆盖）", str(exc), parent=root)
        root.destroy()
        return
    root.mainloop()


''', '启动异常处理')

    # Parse before writing; AST parse does not need tkinter to run.
    ast.parse(s, filename="todo_desktop.py")
    return s


def main():
    if not SOURCE.exists():
        raise SystemExit("未找到 todo_desktop.py。请将升级包里的三个 .py 文件解压到原程序文件夹再运行。")
    for required in ("todo_v2_core.py", "todo_v2_review.py"):
        if not (HERE / required).is_file():
            raise SystemExit("升级文件缺失：" + required)
    old = SOURCE.read_text(encoding="utf-8")
    updated = patch(old)
    if "--dry-run" in sys.argv:
        print("检查通过，能够应用补丁；尚未改动任何文件。")
        return
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_folder = HERE / ("todo_backup_before_v2_" + stamp)
    backup_folder.mkdir(exist_ok=False)
    shutil.copy2(SOURCE, backup_folder / "todo_desktop.py")
    for name in ("tasks.json", "归档.md", "config.json"):
        file = HERE / name
        if file.is_file():
            shutil.copy2(file, backup_folder / name)
    fd, staged = tempfile.mkstemp(prefix=".todo_v2_", suffix=".py", dir=str(HERE))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(updated)
            f.flush()
            os.fsync(f.fileno())
        os.replace(staged, SOURCE)
    finally:
        if os.path.exists(staged):
            os.remove(staged)
    print("升级完成！原始源码与可用的数据快照备份在：", backup_folder.name)
    print("现在可以运行 python todo_desktop.py 测试。遇到问题请先恢复备份。")


if __name__ == "__main__":
    main()
