@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 upgrade_todo_v2.py
) else (
  python upgrade_todo_v2.py
)
echo.
echo Upgrade step finished. Check the message above.
pause
